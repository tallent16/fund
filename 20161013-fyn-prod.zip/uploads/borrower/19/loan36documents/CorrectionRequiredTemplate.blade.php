Dear {{$useremail}},<br><br>

Your Borrower Profile correction required. Please corrected the errors and send back to approval. Please refer the comments.
