<?php
$mysqli=mysqli_connect('localhost','root','','userreg') or die("Database Error");
?>