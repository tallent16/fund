
<canvas id="cbar" width="350" height="100"></canvas>
<div id="cbarlegend" class="chart-legend"></div>
