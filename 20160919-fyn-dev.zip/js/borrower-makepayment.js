$(document).ready(function (){ 
	// date picker
	$("#save_form_payment").submit(function() {
		$("input").removeAttr("disabled");
	});	
	
});
