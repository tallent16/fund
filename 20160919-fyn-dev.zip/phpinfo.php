<?php

  phpinfo();
?>
