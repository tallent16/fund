@var	$par_sub_allowed_yes		=	""
@var	$par_sub_allowed_no			=	""
@var	$par_sub_allowed_disabled	=	"disabled"
@if($BorModLoan->partial_sub_allowed	==	1)
	@var	$par_sub_allowed_yes		=	"checked"
	@var	$par_sub_allowed_disabled	=	""
@else
	@var	$par_sub_allowed_no			=	"checked"
@endif  

<div id="loans_info" class="tab-pane fade in active">
	<div class="panel panel-default applyloan">   
		<div class="panel-body">	
			<fieldset {{$BorModLoan->viewStatus}}>	
			
				<div class="row">		
					<div class="col-xs-12 col-sm-5 col-lg-3">
						<label class="input-required">
							{{ Lang::get('borrower-applyloan.purpose_of_loan_type') }}
						</label>
					</div>	
					<div class="col-xs-12 col-sm-7 col-lg-3" id="purpose_singleline_parent">															   
						{{ Form::select('purpose_singleline', 
									$BorModLoan->purposeSingleLineInfo, 
									$BorModLoan->purpose_singleline, 
									["class" => "selectpicker required",
																"id"=>"purpose_singleline"]) }}  	
					</div>
					
					<div class="col-xs-12 col-sm-5 col-lg-3">											
							<label>
								{{ Lang::get('Loan Reference Number') }}
							</label>												
					</div>																
					<div class="col-xs-12 col-sm-7 col-lg-3" id="loan_ref_num_parent">													
						<input type="text" class="form-control select-width amount-align" 
								name="loan_ref_num"												
								id="loan_ref_num"
								value="{{$BorModLoan->loan_reference_number}}" disabled >										
					</div>
				</div>
				<!---------------------------------row1---------------------------------------->
				<div class="row">		
					<div class="col-xs-12 col-sm-5 col-lg-3">
						<label class="input-required">
							{{ Lang::get('borrower-applyloan.purpose_of_loan') }}
						</label>
					</div>	
					<div class="col-xs-12 col-sm-7 col-lg-3" id="laon_purpose_parent">															   
						<textarea class="form-control required" 
									name="laon_purpose" 
									id="laon_purpose" 
									rows="3">{{$BorModLoan->purpose}}</textarea> 	
					</div>
					
					<div class="col-xs-12 col-sm-5 col-lg-3">											
						<label class="input-required">
							{{ Lang::get('borrower-applyloan.loan_amount') }}
						</label>												
					</div>													
					<div class="col-xs-12 col-sm-7 col-lg-3" id="loan_amount_parent">													
						<input 	type="text" 
								class="form-control select-width text-right required amount-align"
								name="loan_amount"												
								id="loan_amount" 
								decimal="2"
								value="{{$BorModLoan->apply_amount}}"
								{{$BorModLoan->viewStatus}}>												
					</div>					
				</div>
			</fieldset>	
				<!------------------------------------row2----------------------------->
				<div class="row">	
					<div class="col-xs-12 col-sm-5 col-lg-3">											
						<label class="input-required">{{ Lang::get('borrower-applyloan.bid_type') }}</label>												
					</div>																
					<div class="col-xs-12 col-sm-7 col-lg-3" id="bid_type_parent">													
						<select 	id="bid_type" 
									name="bid_type" 
									class="selectpicker required"> 
							{{$BorModLoan->bidTypeSelectOptions}}
						</select>												
					</div>						
							
					<div class="col-xs-12 col-sm-5 col-lg-3">											
						<label class="input-required">
							{{ Lang::get('borrower-applyloan.loan_tenure') }}
						</label>												
					</div>																
					<div class="col-xs-12 col-sm-7 col-lg-3" id="date-picker-2_parent">	
						{{ Form::select('loan_tenure', $BorModLoan->loan_tenure_list, $BorModLoan->loan_tenure,
																["class" => "selectpicker text-right required",
																"id"=>"loan_tenure"]
																) 
						}}			
					</div>
				</div>	
				<!--------------------------------row3----------------------------------->	
			<fieldset {{$BorModLoan->viewStatus}}>	
				<div class="row">		
					<div class="col-xs-12 col-sm-5 col-lg-3">											
						<label class="input-required">
							{{ Lang::get('borrower-applyloan.target_int') }}
						</label>												
					</div>
					<div class="col-xs-6 col-sm-4 col-lg-2" id="target_interest_parent">	
						<input type="text" class="form-control select-width text-right required amount-align" 
								name="target_interest"												
								id="target_interest"
								decimal="2"															
								value="{{$BorModLoan->target_interest}}" >		
					</div> 	
					<div class="col-lg-1 col-sm-3 col-xs-6"></div>
					<div class="col-xs-12 col-sm-5 col-lg-3">											
						<label class="input-required">
							{{ Lang::get('borrower-applyloan.payment_type') }}
						</label>												
					</div>
					<div class="col-xs-5 col-sm-4 col-lg-2" >
						<select id="payment_type" 
								name="payment_type" 
								class="selectpicker">
								{{$BorModLoan->paymentTypeSelectOptions}}
						</select>	
					</div>							
				</div>
				<!--------------------------------row4----------------------------------->	
				<div class="row">						
					<div class="col-xs-12 col-sm-5 col-lg-3">											
						<label class="input-required">
							{{ Lang::get('borrower-applyloan.accept_partial_sub') }}
						</label>												
					</div>																	
					<div class="col-xs-12 col-sm-7 col-lg-3" id="payment_type_parent">	<label class="radio-inline">
							<input 	type="radio" 
									name="partial_sub_allowed"
									value="1"
									{{$par_sub_allowed_yes}} >
							{{ Lang::get('borrower-applyloan.yes') }}
						</label>
						<label class="radio-inline">
							<input 	type="radio" 
									name="partial_sub_allowed"
									value="2"
									{{$par_sub_allowed_no}}>
							{{ Lang::get('borrower-applyloan.no') }}
						</label>														
					</div>	
					
					<div class="col-xs-12 col-sm-5 col-lg-3">											
						<label class="input-required">
							{{ Lang::get('borrower-applyloan.minimum_limit') }}
						</label>												
					</div>																
					<div class="col-xs-12 col-sm-7 col-lg-3" id="min_for_partial_sub_parent">														 
						<input 	type="text" 
								class="form-control select-width text-right amount-align"
								 name="min_for_partial_sub"
								 id="min_for_partial_sub"
								 decimal="2"
								 {{$par_sub_allowed_disabled}}
								 value="{{$BorModLoan->min_for_partial_sub}}">																				
					</div>
				</div>
			</fieldset>	
		</div><!--panel-body--->
		
	</div><!--panel---->
</div><!--first-tab--->
