<div class='row'>
	<div class='col-sm-12'>
		<div class='col-sm-12'>
			{{$message}}
		</div>
	</div>
</div>

